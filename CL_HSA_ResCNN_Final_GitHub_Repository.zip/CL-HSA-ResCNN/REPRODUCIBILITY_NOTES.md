# Reproducibility notes and manuscript alignment

## Information explicitly available in the revised manuscript
- Cohort counts and label counts: ADNI 750/820/680/750; OASIS-3 420/360/270; AIBL 520/470/350.
- Baseline T1-weighted MRI; BET, N4, z-score, MNI registration; training-only augmentation.
- Subject-wise five-fold evaluation; seed 42.
- 3D volume input 128³; PyTorch 2.x/CUDA 12; Adam β=(0.9,0.999).
- CLO population 10, 20 iterations, two leaders, β1=0.7, β2=0.3; search LR 1e-4–1e-3, c 0.1–1.0, τ 0.5–2.0; weight decay 1e-5.
- Up to 120 epochs and patience 15; c=0.6 and τ=1.2 reported as selected values.
- Metrics, reported tables, ablation, confusion matrix and confidence intervals are preserved under `results/paper_reported/`.

## Details that are not fully specified in the manuscript
The manuscript does not provide the complete original source code, exact per-subject scan manifest, actual fold assignment CSVs, checkpoint weights, full optimizer state, full epoch histories, exact numerical residual stage widths/block configuration, exact center-loss coefficient, exact validation fraction, all preprocessing software versions/parameters, or machine-readable complete CLO update equations. Some tables describe 2D and 3D settings while the proposed architecture is described as volumetric.

The defaults in this repository are therefore a transparent implementation of the described method, not a claim that they are bit-for-bit identical to the authors' original training run. Replace any implementation choices with the exact experiment records before publication as a reproducibility package.

## Important internal consistency checks before public release
1. Reconcile Table 2's "100–150 epochs" with the explicit maximum of 120 epochs in Section 3.10.
2. Confirm whether all model comparisons used 3D 128³ inputs or some 2D 224² inputs.
3. Confirm whether the confusion matrix in Table 4.1 was pooled over all out-of-fold predictions and verify the row totals.
4. Ensure the reported metrics and CIs can be regenerated from saved fold predictions.
5. Ensure paired tests use matched fold-level values, and report the exact fold metric vectors.
6. Confirm the exact CLO implementation and clarify whether CLO tunes only LR/c/τ or additional network parameters.
7. Add trained checkpoints, training logs, and fold-level prediction files only after actual runs and after data-use review.
