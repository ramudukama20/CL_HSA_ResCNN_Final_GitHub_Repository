# Data use, privacy, and ethics

This software repository contains no MRI scans or subject-level data. ADNI, OASIS-3, and AIBL are controlled or governed research resources; availability does not mean unrestricted redistribution. Researchers must obtain access independently, follow the applicable data-use agreements, and cite the dataset-specific publications and custodians.

Before publishing derived artifacts:
- Remove direct identifiers and protected health information.
- Review cohort terms for permission to share processed images, embeddings, labels, split manifests, and predictions.
- Prefer aggregate metrics and non-identifying plots.
- Do not commit MRI volumes, masks, scan-level metadata, or fold manifests containing sensitive identifiers unless explicitly permitted.
- The model is for research only and is not a diagnostic system.
