import torch.nn.functional as F
from clhsa.models.network import CenterLoss

class CombinedObjective:
    def __init__(self, num_classes, feature_dim, center_weight=0.01, l2_weight=1e-5):
        self.center=CenterLoss(num_classes,feature_dim)
        self.center_weight=center_weight
        self.l2_weight=l2_weight
    def __call__(self, logits, features, labels, model):
        ce=F.cross_entropy(logits,labels)
        cl=self.center(features,labels)
        l2=sum((p*p).sum() for n,p in model.named_parameters() if p.requires_grad and "bias" not in n)
        total=ce+self.center_weight*cl+self.l2_weight*l2
        return total, {"cross_entropy":float(ce.detach()),"center_loss":float(cl.detach()),"l2":float(l2.detach())}
