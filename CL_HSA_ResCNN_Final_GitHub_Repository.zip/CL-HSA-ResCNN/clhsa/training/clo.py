import numpy as np

class ChefLeaderOptimizer:
    """Population-based search over [learning_rate, curvature, attention_temperature].

    The manuscript specifies population=10, iterations=20, two leaders and
    beta_explore=0.7 / beta_exploit=0.3. Its exact vector update equations are
    not fully machine-readable in the supplied document; this implementation
    operationalizes the described chef exploration and leader exploitation.
    """
    def __init__(self, cfg, seed=42):
        self.rng=np.random.default_rng(seed)
        self.n=int(cfg["population_size"]); self.iters=int(cfg["iterations"])
        self.k=int(cfg["leaders"])
        self.beta1=float(cfg["beta_explore"]); self.beta2=float(cfg["beta_exploit"])
        self.bounds=np.array([cfg["learning_rate_bounds"],cfg["curvature_bounds"],
                              cfg["temperature_bounds"]],dtype=float)
        self.history=[]

    def optimize(self, fitness):
        pop=self.rng.uniform(self.bounds[:,0],self.bounds[:,1],size=(self.n,3))
        scores=np.array([fitness(p) for p in pop],dtype=float)
        for it in range(self.iters):
            order=np.argsort(scores); leaders=pop[order[:self.k]].copy()
            best=float(scores[order[0]])
            self.history.append({"iteration":it+1,"best_validation_loss":best,
                                 "best_lr":float(leaders[0,0]),"best_curvature":float(leaders[0,1]),
                                 "best_temperature":float(leaders[0,2])})
            for i in range(self.n):
                leader=leaders[self.rng.integers(0,len(leaders))]
                r1,r2=self.rng.random(2)
                chef=pop[i]+self.beta1*r1*(leader-pop[i])+0.05*self.rng.normal(size=3)*(self.bounds[:,1]-self.bounds[:,0])
                leader_step=leader+self.beta2*r2*(leaders[0]-leader)
                candidate=0.5*chef+0.5*leader_step
                candidate=np.clip(candidate,self.bounds[:,0],self.bounds[:,1])
                score=float(fitness(candidate))
                if score < scores[i]:
                    pop[i],scores[i]=candidate,score
        best_idx=int(np.argmin(scores))
        return pop[best_idx],self.history
