import os, json, time, random
from pathlib import Path
import numpy as np
import torch
from torch.utils.data import DataLoader
from clhsa.data.dataset import MRIVolumeDataset
from clhsa.models.network import CLHSAResCNN
from clhsa.training.losses import CombinedObjective

def seed_everything(seed=42):
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic=True
    torch.backends.cudnn.benchmark=False

def label_map(dataset):
    return {"ADNI":{"NC":0,"MCI_EARLY":1,"MCI_LATE":2,"AD":3},
            "OASIS3":{"NC":0,"MCI":1,"AD":2},
            "AIBL":{"NC":0,"MCI":1,"AD":2}}[dataset.upper().replace("-","")]

def build_model(cfg, dataset):
    m=cfg["model"]; n=len(label_map(dataset))
    return CLHSAResCNN(num_classes=n,in_channels=m["in_channels"],base_channels=m["base_channels"],
        stages=tuple(m["stages"]),hyperbolic_dim=m["hyperbolic_dim"],curvature=m["curvature"],
        attention_temperature=m["attention_temperature"],attention_grid=tuple(m["attention_grid"]),
        dropout=m["dropout"])

def train_one_fold(train_df,val_df,test_df,cfg,dataset,fold,out_root,override=None):
    seed_everything(cfg["seed"]); device=torch.device("cuda" if torch.cuda.is_available() else "cpu")
    labels=label_map(dataset); nclass=len(labels)
    aug=cfg["augmentation"]
    tr=MRIVolumeDataset(train_df,labels,True,aug); va=MRIVolumeDataset(val_df,labels,False,aug)
    te=MRIVolumeDataset(test_df,labels,False,aug)
    tc=cfg["training"]; bs=int(tc["batch_size"])
    train_loader=DataLoader(tr,batch_size=bs,shuffle=True,num_workers=tc["num_workers"],pin_memory=True)
    val_loader=DataLoader(va,batch_size=1,shuffle=False,num_workers=tc["num_workers"])
    test_loader=DataLoader(te,batch_size=1,shuffle=False,num_workers=tc["num_workers"])
    model=build_model(cfg,dataset).to(device)
    lr=float((override or {}).get("lr",tc["learning_rate"]))
    if override:
        model.set_geometry(override.get("curvature"),override.get("temperature"))
    optimizer=torch.optim.Adam(model.parameters(),lr=lr,betas=tuple(tc["adam_betas"]),
                               weight_decay=float(tc["weight_decay"]))
    feat_dim=model.backbone.out_channels
    objective=CombinedObjective(nclass,feat_dim,tc["center_loss_weight"],tc["weight_decay"])
    objective.center.to(device)
    optimizer.add_param_group({"params":objective.center.parameters()})
    scaler=torch.amp.GradScaler("cuda",enabled=(device.type=="cuda" and tc.get("amp",True)))
    out=Path(out_root); out.mkdir(parents=True,exist_ok=True)
    best=float("inf"); bad=0; history=[]
    for epoch in range(1,int(tc["max_epochs"])+1):
        t0=time.time(); model.train(); losses=[]
        for x,y,_ in train_loader:
            x,y=x.to(device),y.to(device); optimizer.zero_grad(set_to_none=True)
            with torch.autocast(device_type=device.type,enabled=(device.type=="cuda" and tc.get("amp",True))):
                logits,features,_,_=model(x,return_features=True)
                loss,_=objective(logits,features,y,model)
            scaler.scale(loss).backward()
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(),tc["gradient_clip_norm"])
            scaler.step(optimizer); scaler.update(); losses.append(float(loss.detach()))
        model.eval(); vloss=[]; correct=total=0
        with torch.no_grad():
            for x,y,_ in val_loader:
                x,y=x.to(device),y.to(device)
                logits,features,_,_=model(x,return_features=True)
                loss,_=objective(logits,features,y,model)
                vloss.append(float(loss)); correct+=(logits.argmax(1)==y).sum().item(); total+=len(y)
        val_loss=float(np.mean(vloss)); row={"epoch":epoch,"train_loss":float(np.mean(losses)),
            "validation_loss":val_loss,"validation_accuracy":correct/max(total,1),
            "seconds":time.time()-t0}
        history.append(row)
        if val_loss < best:
            best=val_loss; bad=0
            torch.save({"model":model.state_dict(),"optimizer":optimizer.state_dict(),
                        "epoch":epoch,"config":cfg,"label_map":labels,"best_val_loss":best},
                       out/f"fold_{fold}_best.pt")
        else: bad+=1
        with open(out/f"fold_{fold}_history.json","w") as f: json.dump(history,f,indent=2)
        if bad>=int(tc["early_stopping_patience"]): break

    ckpt=torch.load(out/f"fold_{fold}_best.pt",map_location=device,weights_only=False)
    model.load_state_dict(ckpt["model"]); model.eval()
    preds=[]
    with torch.no_grad():
        for x,y,sid in test_loader:
            x=x.to(device); logits=model(x); prob=torch.softmax(logits,1)[0].cpu().numpy()
            preds.append({"subject_id":sid[0],"true_label":int(y.item()),"pred_label":int(prob.argmax()),
                          "probabilities":prob.tolist(),"fold":int(fold)})
    import pandas as pd
    pd.DataFrame(preds).to_json(out/f"fold_{fold}_predictions.json",orient="records",indent=2)
    return history,preds
