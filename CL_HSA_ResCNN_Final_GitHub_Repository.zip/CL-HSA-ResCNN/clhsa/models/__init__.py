from .network import CLHSAResCNN
