"""Reference baseline definitions. Confirm 2D/3D protocol against manuscript before comparison."""
import torch
from torch import nn
import torch.nn.functional as F

class Simple3DCNN(nn.Module):
    def __init__(self, num_classes=4):
        super().__init__()
        self.features=nn.Sequential(
            nn.Conv3d(1,16,3,padding=1),nn.BatchNorm3d(16),nn.ReLU(),nn.MaxPool3d(2),
            nn.Conv3d(16,32,3,padding=1),nn.BatchNorm3d(32),nn.ReLU(),nn.MaxPool3d(2),
            nn.Conv3d(32,64,3,padding=1),nn.BatchNorm3d(64),nn.ReLU(),nn.MaxPool3d(2),
            nn.Conv3d(64,128,3,padding=1),nn.BatchNorm3d(128),nn.ReLU(),nn.AdaptiveAvgPool3d(1))
        self.classifier=nn.Linear(128,num_classes)
    def forward(self,x): return self.classifier(self.features(x).flatten(1))

def build_torchvision_2d_baseline(name, num_classes=4, pretrained=False):
    """Build ResNet-50, DenseNet-121, ViT-B/16, or Swin-T for 2D slice experiments."""
    from torchvision import models
    key=name.lower().replace('-','').replace('_','')
    if key in ('resnet50','resnet'):
        m=models.resnet50(weights=models.ResNet50_Weights.DEFAULT if pretrained else None)
        m.conv1=nn.Conv2d(1,64,7,2,3,bias=False); m.fc=nn.Linear(m.fc.in_features,num_classes)
    elif key in ('densenet121','densenet'):
        m=models.densenet121(weights=models.DenseNet121_Weights.DEFAULT if pretrained else None)
        m.features.conv0=nn.Conv2d(1,64,7,2,3,bias=False); m.classifier=nn.Linear(m.classifier.in_features,num_classes)
    elif key in ('vitbase','vitb16','vit'):
        m=models.vit_b_16(weights=models.ViT_B_16_Weights.DEFAULT if pretrained else None)
        m.conv_proj=nn.Conv2d(1,m.conv_proj.out_channels,kernel_size=16,stride=16); m.heads.head=nn.Linear(m.heads.head.in_features,num_classes)
    elif key in ('swint','swintransformer'):
        m=models.swin_t(weights=models.Swin_T_Weights.DEFAULT if pretrained else None)
        # Torchvision Swin patch embedding is RGB; adapt first projection to one channel.
        old=m.features[0][0]
        m.features[0][0]=nn.Conv2d(1,old.out_channels,kernel_size=old.kernel_size,stride=old.stride,padding=old.padding)
        m.head=nn.Linear(m.head.in_features,num_classes)
    else:
        raise ValueError(f'Unknown 2D baseline: {name}')
    return m
