import torch
from torch import nn
import torch.nn.functional as F

class ResidualBlock3D(nn.Module):
    def __init__(self, in_ch, out_ch, stride=1):
        super().__init__()
        self.conv1 = nn.Conv3d(in_ch, out_ch, 3, stride=stride, padding=1, bias=False)
        self.bn1 = nn.BatchNorm3d(out_ch)
        self.conv2 = nn.Conv3d(out_ch, out_ch, 3, padding=1, bias=False)
        self.bn2 = nn.BatchNorm3d(out_ch)
        self.skip = nn.Identity() if in_ch == out_ch and stride == 1 else nn.Sequential(
            nn.Conv3d(in_ch, out_ch, 1, stride=stride, bias=False), nn.BatchNorm3d(out_ch))
        self.act = nn.ReLU(inplace=True)

    def forward(self, x):
        return self.act(self.bn2(self.conv2(self.act(self.bn1(self.conv1(x))))) + self.skip(x))

class ResidualBackbone3D(nn.Module):
    def __init__(self, in_ch=1, base=16, blocks=(2,2,2,2)):
        super().__init__()
        self.stem = nn.Sequential(nn.Conv3d(in_ch, base, 7, stride=2, padding=3, bias=False),
                                   nn.BatchNorm3d(base), nn.ReLU(inplace=True),
                                   nn.MaxPool3d(3, stride=2, padding=1))
        stages=[]; ch=base
        for i, n in enumerate(blocks):
            out=base*(2**i)
            layer=[ResidualBlock3D(ch,out,stride=1 if i==0 else 2)]
            layer += [ResidualBlock3D(out,out) for _ in range(n-1)]
            stages.append(nn.Sequential(*layer)); ch=out
        self.stages=nn.ModuleList(stages)
        self.out_channels=ch

    def forward(self,x):
        x=self.stem(x)
        for stage in self.stages: x=stage(x)
        return x

class HyperbolicSelfAttention(nn.Module):
    """Poincare-ball projection -> log map -> multihead attention -> exp map."""
    def __init__(self, channels, embed_dim=128, curvature=0.6, temperature=1.2, heads=4):
        super().__init__()
        self.c=float(curvature); self.temperature=float(temperature)
        self.proj=nn.Linear(channels,embed_dim)
        self.attn=nn.MultiheadAttention(embed_dim, heads, batch_first=True)
        self.norm=nn.LayerNorm(embed_dim)
        self.out=nn.Linear(embed_dim,channels)

    def set_geometry(self, curvature=None, temperature=None):
        if curvature is not None: self.c=float(curvature)
        if temperature is not None: self.temperature=float(temperature)

    def mobius_project(self, x):
        c=max(self.c,1e-6)
        norm=x.norm(dim=-1,keepdim=True).clamp_min(1e-8)
        max_norm=(1.0-1e-5)/(c**0.5)
        scale=torch.clamp(max_norm/norm, max=1.0)
        return x*scale

    def log0(self, u):
        c=max(self.c,1e-6)
        norm=u.norm(dim=-1,keepdim=True).clamp_min(1e-8)
        return (2.0/(c**0.5))*torch.atanh((c**0.5*norm).clamp(max=1-1e-5))*u/norm

    def exp0(self, v):
        c=max(self.c,1e-6)
        norm=v.norm(dim=-1,keepdim=True).clamp_min(1e-8)
        return torch.tanh((c**0.5)*norm/2.0)*v/(c**0.5*norm)

    def forward(self, feature_map):
        b,c,d,h,w=feature_map.shape
        tokens=feature_map.flatten(2).transpose(1,2)
        z=self.proj(tokens)
        u=self.mobius_project(torch.tanh(z))
        tangent=self.log0(u)
        # Temperature scales attention logits in the tangent space.
        qkv=tangent / max(self.temperature,1e-4)
        attended,_=self.attn(qkv,qkv,qkv,need_weights=True,average_attn_weights=True)
        attended=self.norm(attended+tangent)
        hyp=self.exp0(attended)
        out=self.out(hyp).transpose(1,2).reshape(b,c,d,h,w)
        return out

class CenterLoss(nn.Module):
    def __init__(self, num_classes, feat_dim):
        super().__init__()
        self.centers=nn.Parameter(torch.randn(num_classes,feat_dim)*0.02)
    def forward(self, features, labels):
        return ((features-self.centers[labels])**2).sum(dim=1).mean()

class CLHSAResCNN(nn.Module):
    def __init__(self, num_classes=4, in_channels=1, base_channels=16,
                 stages=(2,2,2,2), hyperbolic_dim=128, curvature=0.6,
                 attention_temperature=1.2, attention_grid=(4,4,4), dropout=0.3):
        super().__init__()
        self.backbone=ResidualBackbone3D(in_channels,base_channels,stages)
        ch=self.backbone.out_channels
        self.attention=HyperbolicSelfAttention(ch,hyperbolic_dim,curvature,attention_temperature)
        self.pool_grid=tuple(attention_grid)
        self.fuse=nn.Sequential(nn.Conv3d(ch*2,ch,1,bias=False),nn.BatchNorm3d(ch),nn.ReLU(inplace=True))
        self.global_pool=nn.AdaptiveAvgPool3d(1)
        self.dropout=nn.Dropout(dropout)
        self.classifier=nn.Linear(ch,num_classes)

    def forward(self,x,return_features=False):
        cnn=self.backbone(x)
        small=F.adaptive_avg_pool3d(cnn,self.pool_grid)
        att_small=self.attention(small)
        att=F.interpolate(att_small,size=cnn.shape[2:],mode="trilinear",align_corners=False)
        fused=self.fuse(torch.cat([cnn,att],dim=1))
        vector=self.global_pool(fused).flatten(1)
        logits=self.classifier(self.dropout(vector))
        if return_features:
            return logits, vector, fused, att
        return logits

    def set_geometry(self, curvature=None, temperature=None):
        self.attention.set_geometry(curvature,temperature)
