import numpy as np
from sklearn.metrics import (accuracy_score, precision_recall_fscore_support,
    confusion_matrix, roc_auc_score)

def calculate_metrics(y_true,y_pred,y_prob,num_classes):
    labels=list(range(num_classes))
    acc=accuracy_score(y_true,y_pred)
    p,r,f,_=precision_recall_fscore_support(y_true,y_pred,labels=labels,average="macro",zero_division=0)
    cm=confusion_matrix(y_true,y_pred,labels=labels)
    specs=[]
    for i in labels:
        tp=cm[i,i]; fn=cm[i,:].sum()-tp; fp=cm[:,i].sum()-tp
        tn=cm.sum()-tp-fn-fp
        specs.append(tn/max(tn+fp,1))
    try:
        auc=roc_auc_score(y_true,y_prob,multi_class="ovr",average="macro",labels=labels)
    except ValueError:
        auc=float("nan")
    return {"accuracy":float(acc),"precision_macro":float(p),"recall_macro":float(r),
            "f1_macro":float(f),"specificity_macro":float(np.mean(specs)),
            "auc_ovr_macro":float(auc),"confusion_matrix":cm.tolist()}
