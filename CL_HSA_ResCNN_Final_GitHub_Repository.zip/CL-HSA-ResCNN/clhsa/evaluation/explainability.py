import torch
import torch.nn.functional as F

def gradcam_3d(model, volume, target_layer, class_idx=None):
    """Returns a normalized 3D Grad-CAM map for one input volume."""
    activations=[]; gradients=[]
    def fwd(_,__,out): activations.append(out)
    def bwd(_,gin,gout): gradients.append(gout[0])
    h1=target_layer.register_forward_hook(fwd)
    h2=target_layer.register_full_backward_hook(bwd)
    model.zero_grad(set_to_none=True)
    logits=model(volume)
    if class_idx is None: class_idx=int(logits.argmax(1).item())
    logits[:,class_idx].sum().backward()
    a=activations[-1]; g=gradients[-1]
    weights=g.mean(dim=(2,3,4),keepdim=True)
    cam=F.relu((weights*a).sum(dim=1,keepdim=True))
    cam=F.interpolate(cam,size=volume.shape[2:],mode="trilinear",align_corners=False)
    cam=cam-cam.amin(dim=(2,3,4),keepdim=True)
    cam=cam/(cam.amax(dim=(2,3,4),keepdim=True)+1e-8)
    h1.remove(); h2.remove()
    return cam.detach()
