import numpy as np
from scipy.stats import ttest_rel
from statsmodels.stats.multitest import multipletests

def paired_fold_tests(proposed, baselines):
    """Paired two-sided t-tests across matched outer folds; Holm correction per metric."""
    output={}
    for metric in ("accuracy","f1"):
        names=list(baselines)
        raw=[float(ttest_rel(proposed[metric],baselines[n][metric]).pvalue) for n in names]
        adj=multipletests(raw,method="holm")[1] if raw else []
        output[metric]={n:{"raw_p":p,"holm_p":float(a),"significant":bool(a<0.05)}
                        for n,p,a in zip(names,raw,adj)}
    return output
