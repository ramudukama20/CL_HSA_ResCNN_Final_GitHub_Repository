import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset
import nibabel as nib
from scipy.ndimage import rotate, zoom

class MRIVolumeDataset(Dataset):
    def __init__(self, frame, label_to_idx, augment=False, aug_cfg=None):
        self.frame = frame.reset_index(drop=True)
        self.label_to_idx = label_to_idx
        self.augment = augment
        self.aug_cfg = aug_cfg or {}

    def __len__(self):
        return len(self.frame)

    def _augment(self, x):
        if not self.augment or not self.aug_cfg.get("enabled", True):
            return x
        # Independent, small in-plane rotations preserve 3D shape.
        deg = float(self.aug_cfg.get("rotation_degrees", 8))
        if np.random.rand() < 0.5:
            x = rotate(x, np.random.uniform(-deg, deg), axes=(1,2), reshape=False, order=1, mode="nearest")
        if np.random.rand() < float(self.aug_cfg.get("flip_probability", 0.5)):
            x = np.flip(x, axis=np.random.choice([0,1,2])).copy()
        scale_range = self.aug_cfg.get("scale_range", [0.95,1.05])
        if np.random.rand() < 0.5:
            x = x * np.random.uniform(*scale_range)
        return x.astype(np.float32)

    def __getitem__(self, idx):
        row = self.frame.iloc[idx]
        x = nib.load(str(row.image_path)).get_fdata(dtype=np.float32)
        x = np.nan_to_num(x)
        x = self._augment(x)
        x = np.ascontiguousarray(x[None, ...])
        y = self.label_to_idx[str(row.label)]
        return torch.from_numpy(x), torch.tensor(y, dtype=torch.long), str(row.subject_id)
