from pathlib import Path
import pandas as pd

REQUIRED = {"dataset", "subject_id", "scan_id", "image_path", "label"}
LABELS = {
    "ADNI": ["NC", "MCI_EARLY", "MCI_LATE", "AD"],
    "OASIS3": ["NC", "MCI", "AD"],
    "AIBL": ["NC", "MCI", "AD"],
}

def load_manifest(path, dataset=None):
    df = pd.read_csv(path)
    missing = REQUIRED - set(df.columns)
    if missing:
        raise ValueError(f"Manifest missing columns: {sorted(missing)}")
    if df[list(REQUIRED)].isna().any().any():
        raise ValueError("Required manifest fields contain missing values")
    df["dataset"] = df["dataset"].astype(str).str.upper().str.replace("-", "")
    if dataset:
        key = dataset.upper().replace("-", "")
        df = df[df.dataset == key].copy()
        if df.empty:
            raise ValueError(f"No rows found for dataset {dataset}")
    if df.duplicated(["dataset", "subject_id"]).any():
        # The manuscript states one baseline scan per subject; enforce that here.
        dup = df[df.duplicated(["dataset", "subject_id"], keep=False)]
        raise ValueError("More than one scan per subject detected. Resolve baseline scan selection first: "
                         + ", ".join(dup.subject_id.astype(str).unique()[:10]))
    for ds, group in df.groupby("dataset"):
        allowed = set(LABELS.get(ds, []))
        unknown = set(group.label.astype(str)) - allowed
        if unknown:
            raise ValueError(f"Unknown labels for {ds}: {sorted(unknown)}")
    for p in df.image_path:
        if not Path(str(p)).exists():
            raise FileNotFoundError(f"Image does not exist: {p}")
    return df.reset_index(drop=True)
