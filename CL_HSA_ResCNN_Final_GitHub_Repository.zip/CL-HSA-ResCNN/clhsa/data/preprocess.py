import os, subprocess
from pathlib import Path
import numpy as np
import nibabel as nib
from scipy.ndimage import zoom

def _run(cmd):
    print("+", " ".join(map(str, cmd)))
    subprocess.run(list(map(str, cmd)), check=True)

def preprocess_one(image_path, out_path, cfg, subject_id="unknown"):
    """Run BET -> N4 -> ANTs registration -> z-score -> 128^3 NIfTI.

    External tools are invoked only when enabled. No registration or skull-stripping
    is silently simulated. Inspect the output and QC before use.
    """
    paths, pcfg = cfg["paths"], cfg["preprocessing"]
    image_path, out_path = Path(image_path), Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    work = out_path.parent / f".work_{subject_id}"
    work.mkdir(exist_ok=True)
    current = image_path

    if pcfg.get("run_bet", True):
        bet_out = work / "brain.nii.gz"
        _run(["bet", current, bet_out, "-R", "-f", str(pcfg.get("bet_fractional_intensity", 0.5)), "-m"])
        current = bet_out
        mask_path = Path(str(bet_out).replace(".nii.gz", "_mask.nii.gz"))
    else:
        mask_path = None

    if pcfg.get("run_n4", True):
        n4_out = work / "n4.nii.gz"
        _run(["N4BiasFieldCorrection", "-d", "3", "-i", current, "-o", n4_out])
        current = n4_out

    if pcfg.get("run_registration", True):
        template = paths["mni_template"]
        prefix = work / "mni_"
        _run(["antsRegistrationSyNQuick.sh", "-d", "3", "-f", template, "-m", current,
              "-o", prefix, "-t", "a"])
        warped = Path(str(prefix) + "Warped.nii.gz")
        current = warped

    img = nib.load(str(current))
    arr = img.get_fdata(dtype=np.float32)
    if mask_path and mask_path.exists():
        mask = nib.load(str(mask_path)).get_fdata() > 0
        if mask.shape != arr.shape:
            mask = np.ones(arr.shape, dtype=bool)
    else:
        mask = arr != 0
    vals = arr[mask]
    mu, sigma = float(vals.mean()), float(vals.std())
    arr = (arr - mu) / max(sigma, 1e-6)
    lo, hi = pcfg.get("clip_zscore", [-5, 5])
    arr = np.clip(arr, lo, hi)
    target = tuple(pcfg.get("output_shape", [128,128,128]))
    factors = [t/s for t,s in zip(target, arr.shape)]
    arr = zoom(arr, factors, order=int(pcfg.get("interpolation_order", 1)))
    arr = arr[tuple(slice(0, t) for t in target)]
    if arr.shape != target:
        padded = np.zeros(target, dtype=np.float32)
        slices = tuple(slice(0, min(a,b)) for a,b in zip(target,arr.shape))
        padded[slices] = arr[slices]
        arr = padded
    out_img = nib.Nifti1Image(arr.astype(np.float32), img.affine, img.header)
    nib.save(out_img, str(out_path))
    return str(out_path)

def preprocess_manifest(df, cfg, out_csv):
    import pandas as pd
    rows = []
    for row in df.to_dict("records"):
        out = Path(cfg["paths"]["processed_root"]) / row["dataset"] / f'{row["scan_id"]}.nii.gz'
        row["source_image_path"] = row["image_path"]
        row["image_path"] = preprocess_one(row["image_path"], out, cfg, row["subject_id"])
        rows.append(row)
    pd.DataFrame(rows).to_csv(out_csv, index=False)
    return out_csv
