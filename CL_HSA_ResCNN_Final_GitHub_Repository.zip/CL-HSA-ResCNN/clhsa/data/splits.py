from pathlib import Path
import pandas as pd
from sklearn.model_selection import StratifiedGroupKFold, GroupShuffleSplit

def make_subject_folds(df, out_dir, n_splits=5, seed=42, validation_fraction=0.15):
    """Outer test folds are subject-disjoint; validation is sampled only from outer train."""
    out = Path(out_dir); out.mkdir(parents=True, exist_ok=True)
    for ds, frame in df.groupby("dataset"):
        frame = frame.reset_index(drop=True)
        splitter = StratifiedGroupKFold(n_splits=n_splits, shuffle=True, random_state=seed)
        y = frame.label.astype(str).values
        groups = frame.subject_id.astype(str).values
        for fold, (trainval_idx, test_idx) in enumerate(splitter.split(frame, y, groups), 1):
            trainval = frame.iloc[trainval_idx].copy()
            test = frame.iloc[test_idx].copy()
            # Group split ensures a subject is not shared between train and validation.
            gss = GroupShuffleSplit(n_splits=1, test_size=validation_fraction, random_state=seed+fold)
            tr_i, va_i = next(gss.split(trainval, trainval.label, trainval.subject_id))
            train, val = trainval.iloc[tr_i], trainval.iloc[va_i]
            assert set(train.subject_id).isdisjoint(set(val.subject_id))
            assert set(train.subject_id).isdisjoint(set(test.subject_id))
            assert set(val.subject_id).isdisjoint(set(test.subject_id))
            fold_dir = out / ds / f"fold_{fold}"
            fold_dir.mkdir(parents=True, exist_ok=True)
            train.to_csv(fold_dir/"train.csv", index=False)
            val.to_csv(fold_dir/"validation.csv", index=False)
            test.to_csv(fold_dir/"test.csv", index=False)
    return out
