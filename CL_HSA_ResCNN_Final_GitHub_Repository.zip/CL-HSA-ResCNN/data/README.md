# Data directory

No MRI data are bundled. Store authorized data locally and keep the raw data directory out of Git.

- `manifests/manifest_template.csv`: schema only; replace illustrative rows before use.
- `manifests/folds/`: generated subject-wise fold CSVs (do not commit sensitive IDs).
- `raw/`, `processed/`: local data directories, ignored by `.gitignore`.

Use pseudonymous study IDs and comply with each cohort's data-use agreement. Do not upload patient scans, protected health information, or restricted cohort records to a public repository.
