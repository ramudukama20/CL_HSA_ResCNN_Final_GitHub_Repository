# Main training notebook

Open `CL_HSA_ResCNN_Main_Training.ipynb` in Google Colab or Jupyter.

The notebook is a self-contained 3D PyTorch training workflow aligned with the manuscript description: residual CNN, Poincare-ball mapping, hyperbolic self-attention, feature fusion, cross-entropy plus center loss, subject-wise five-fold validation, metrics, confusion matrices, checkpoint saving, and an explicitly labelled CLO-inspired search approximation.

## Input manifest
Create `data/manifest.csv` with columns:

- `path`: path to an authorized preprocessed NIfTI volume (`.nii` or `.nii.gz`)
- `label`: diagnosis label
- `subject_id`: participant identifier for grouped cross-validation

ADNI uses the manuscript's four labels (`NC`, `MCI_EARLY`, `MCI_LATE`, `AD`). OASIS-3 and AIBL use `NC`, `MCI`, and `AD`.

## Important
The MRI data are not included. Obtain them through the official data-access procedures. The notebook's computed metrics are new results from the provided data and are not guaranteed to equal the manuscript-reported values. The manuscript does not provide every detail required for exact reconstruction, including a complete executable CLO equation and an explicit center-loss coefficient. The notebook makes such assumptions visible and does not fabricate weights or results.
