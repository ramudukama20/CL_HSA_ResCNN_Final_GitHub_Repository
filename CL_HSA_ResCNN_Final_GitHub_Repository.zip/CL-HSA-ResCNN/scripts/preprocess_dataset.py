import argparse,yaml
from clhsa.data.manifest import load_manifest
from clhsa.data.preprocess import preprocess_manifest
p=argparse.ArgumentParser()
p.add_argument("--manifest",required=True); p.add_argument("--config",required=True)
p.add_argument("--out",default="data/manifests/processed_manifest.csv")
a=p.parse_args()
cfg=yaml.safe_load(open(a.config))
df=load_manifest(a.manifest)
preprocess_manifest(df,cfg,a.out)
print("Wrote",a.out)
