import argparse
from clhsa.data.manifest import load_manifest
from clhsa.data.splits import make_subject_folds
p=argparse.ArgumentParser()
p.add_argument("--manifest",required=True); p.add_argument("--out",default="data/manifests/folds")
p.add_argument("--seed",type=int,default=42); p.add_argument("--validation-fraction",type=float,default=.15)
a=p.parse_args()
df=load_manifest(a.manifest)
make_subject_folds(df,a.out,5,a.seed,a.validation_fraction)
print("Fold manifests written to",a.out)
