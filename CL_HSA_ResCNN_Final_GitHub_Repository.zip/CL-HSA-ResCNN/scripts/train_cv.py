import argparse,yaml,json
from pathlib import Path
import pandas as pd
from clhsa.training.engine import train_one_fold,label_map
from clhsa.training.clo import ChefLeaderOptimizer

p=argparse.ArgumentParser()
p.add_argument("--manifest",required=True); p.add_argument("--fold-dir",required=True)
p.add_argument("--config",required=True); p.add_argument("--dataset",required=True)
p.add_argument("--out",default="results/reproduced"); p.add_argument("--run-clo",action="store_true")
a=p.parse_args(); cfg=yaml.safe_load(open(a.config)); ds=a.dataset.upper().replace("-","")
cfg["dataset"]=ds
root=Path(a.out)/ds
for fold in range(1,6):
    fd=Path(a.fold_dir)/ds/f"fold_{fold}"
    tr=pd.read_csv(fd/"train.csv"); va=pd.read_csv(fd/"validation.csv"); te=pd.read_csv(fd/"test.csv")
    override=None
    if a.run_clo:
        # Search fitness uses validation only. Trial is deliberately small; record this budget.
        def fitness(v):
            trial_cfg=json.loads(json.dumps(cfg)); trial_cfg["training"]["max_epochs"]=cfg["clo"]["trial_epochs"]
            trial_cfg["training"]["early_stopping_patience"]=cfg["clo"]["trial_epochs"]
            _,_=train_one_fold(tr,va,va,trial_cfg,ds,fold,root/"clo_trials",
                               {"lr":float(v[0]),"curvature":float(v[1]),"temperature":float(v[2])})
            # Best validation loss from trial checkpoint metadata.
            import torch
            ck=torch.load(root/"clo_trials"/f"fold_{fold}_best.pt",map_location="cpu",weights_only=False)
            return float(ck["best_val_loss"])
        clo=ChefLeaderOptimizer(cfg["clo"],cfg["seed"]+fold)
        best,hist=clo.optimize(fitness); override={"lr":float(best[0]),"curvature":float(best[1]),"temperature":float(best[2])}
        (root/"clo").mkdir(parents=True,exist_ok=True)
        json.dump({"best":override,"history":hist},open(root/"clo"/f"fold_{fold}.json","w"),indent=2)
    train_one_fold(tr,va,te,cfg,ds,fold,root,override)
print("Training complete:",root)
