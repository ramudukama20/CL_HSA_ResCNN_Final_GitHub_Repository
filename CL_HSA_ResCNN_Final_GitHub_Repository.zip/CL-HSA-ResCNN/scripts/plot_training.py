import argparse,json
from pathlib import Path
import matplotlib.pyplot as plt
p=argparse.ArgumentParser(); p.add_argument("--log-dir",required=True); p.add_argument("--out-dir",required=True); a=p.parse_args()
out=Path(a.out_dir); out.mkdir(parents=True,exist_ok=True)
for f in Path(a.log_dir).glob("fold_*_history.json"):
    h=json.load(open(f)); ep=[x["epoch"] for x in h]
    for key in ("train_loss","validation_loss","validation_accuracy"):
        plt.figure(); plt.plot(ep,[x[key] for x in h]); plt.xlabel("Epoch"); plt.ylabel(key.replace("_"," ").title())
        plt.title(f"{f.stem}: {key}"); plt.grid(True,alpha=.3); plt.tight_layout()
        plt.savefig(out/f"{f.stem}_{key}.png",dpi=300); plt.close()
