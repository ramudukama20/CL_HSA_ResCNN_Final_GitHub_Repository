import argparse,json
from pathlib import Path
import pandas as pd
from scipy.stats import t
import numpy as np
p=argparse.ArgumentParser(); p.add_argument("--pred-dir",required=True); p.add_argument("--out",required=True); a=p.parse_args()
# Fold-level accuracy summaries are derived from held-out predictions.
rows=[]
for f in sorted(Path(a.pred_dir).glob("fold_*_predictions.json")):
    d=pd.read_json(f); rows.append({"fold":int(f.stem.split("_")[1]),"accuracy":float((d.true_label==d.pred_label).mean())})
if len(rows)<2: raise SystemExit("Need at least two fold prediction files.")
vals=np.array([r["accuracy"] for r in rows]); mean=vals.mean(); sd=vals.std(ddof=1)
half=t.ppf(.975,len(vals)-1)*sd/np.sqrt(len(vals))
json.dump({"folds":rows,"mean_accuracy":mean,"sd_accuracy":sd,
           "ci95":[mean-half,mean+half],
           "note":"This is a fold-level descriptive CI; compare with manuscript reporting conventions."},
          open(a.out,"w"),indent=2)
