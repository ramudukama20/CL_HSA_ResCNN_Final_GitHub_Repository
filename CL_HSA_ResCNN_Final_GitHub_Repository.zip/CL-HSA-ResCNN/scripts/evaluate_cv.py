import argparse,json
from pathlib import Path
import pandas as pd
import numpy as np
from clhsa.evaluation.metrics import calculate_metrics
p=argparse.ArgumentParser(); p.add_argument("--pred-dir",required=True); p.add_argument("--out-dir",required=True)
p.add_argument("--num-classes",type=int,default=4); a=p.parse_args()
preds=[]
for f in sorted(Path(a.pred_dir).glob("fold_*_predictions.json")):
    preds += json.load(open(f))
if not preds: raise SystemExit("No fold prediction files found.")
y=np.array([r["true_label"] for r in preds]); yh=np.array([r["pred_label"] for r in preds])
prob=np.array([r["probabilities"] for r in preds])
m=calculate_metrics(y,yh,prob,a.num_classes)
out=Path(a.out_dir); out.mkdir(parents=True,exist_ok=True)
json.dump(m,open(out/"pooled_metrics.json","w"),indent=2)
pd.DataFrame(preds).to_csv(out/"pooled_predictions.csv",index=False)
print(json.dumps(m,indent=2))
