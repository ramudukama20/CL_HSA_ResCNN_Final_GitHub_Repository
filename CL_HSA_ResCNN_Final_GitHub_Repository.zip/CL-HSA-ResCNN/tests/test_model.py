import torch
from clhsa.models.network import CLHSAResCNN

def test_forward_shape():
    model=CLHSAResCNN(num_classes=3,base_channels=4,stages=(1,1,1,1),hyperbolic_dim=16,
                      attention_grid=(2,2,2),dropout=0.0)
    x=torch.randn(1,1,64,64,64)
    y=model(x)
    assert y.shape==(1,3)
