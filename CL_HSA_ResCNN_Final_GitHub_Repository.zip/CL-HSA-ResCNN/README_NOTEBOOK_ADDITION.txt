A main Jupyter training notebook has been added: CL_HSA_ResCNN_Main_Training.ipynb
See NOTEBOOK_GUIDE.md for manifest preparation and execution instructions.
